<?php

namespace App\Http\Controllers\Tenant;

use App\Http\Controllers\Controller;
use App\Http\Requests\Tenant\Customer\CustomerRequest;
use App\Models\Customer;
use App\Models\CustomerContact;
use App\Models\JobType;
use App\Models\LeadSource;
use App\Models\Product;
use App\Models\ProductFamily;
use App\Models\ProductHeight;
use App\Models\User;
use Illuminate\Http\Request;
use Yajra\DataTables\Facades\DataTables;

class CustomerController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        if ($request->ajax()) {
            $data = Customer::where('user_id', auth()->user()->id)
            ->with('contacts')
            ->orderBy('id', 'DESC')
            ->get();
            
            $data->each(function ($customer) {
                $customer->office_contact = $customer->contacts->firstWhere('type', 'Office');
            });

            
            return DataTables::of($data)
                ->addIndexColumn()
                ->addColumn('action', function ($row) {
                    $action = '<span class="action-buttons">
                    <a  href="' . route("customer.show", $row) . '" class="btn btn-sm btn-info btn-b"><i class="las la-eye"></i>
                                </a>
                    <a  href="' . route("customer.edit", $row) . '" class="btn btn-sm btn-info"><i class="las la-pen"></i>
                    </a>
        
                    <a href="' . route("customer.destroy", $row) . '"
                            class="btn btn-sm btn-danger remove_us"
                            title="Delete User"
                            data-toggle="tooltip"
                            data-placement="top"
                            data-method="DELETE"
                            data-confirm-title="Please Confirm"
                            data-confirm-text="Are you sure that you want to delete this?"
                            data-confirm-delete="Yes, delete it!">
                            <i class="las la-trash"></i>
                        </a>
                ';
                            return $action;
                })
                ->rawColumns(['action'])
                ->make(true);
        }
        return view('tenant.customer.index');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $leadSources = LeadSource::all();
        $jobTypes = JobType::all();
        $users = User::with([
            'roles' => function ($query) {
                $query->where('name', 'Sales Rep');
            }
        ])->get();

        return view('tenant.customer.addEdit', compact('leadSources', 'jobTypes', 'users'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(CustomerRequest $request)
    {
       

        $input = $request->all();
        $input['user_id'] = auth()->user()->id;
        $input['updated_by'] = auth()->user()->id;

        $customer = Customer::create($input);
        $customerContactAlternate = $request->alternate;
        $customerContactAlternate['customer_id'] = $customer->id;
        $customerContactAlternate['type'] = 'Alternate';


        CustomerContact::create($customerContactAlternate);

        $customerContactOffice = $request->office;
        $customerContactOffice['customer_id'] = $customer->id;
        $customerContactOffice['type'] = 'Office';

        CustomerContact::create($customerContactOffice);

        return redirect()->back()
            ->with('success', 'Customer created successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show(Customer $customer)
    {
        $families = ProductFamily::all();
        $heights = ProductHeight::all();
        return view('tenant.customer.show', compact('customer', 'families', 'heights'));
    }
  

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Customer $customer)
    {

        $leadSources = LeadSource::all();
        $jobTypes = JobType::all();
        $users = User::with([
            'roles' => function ($query) {
                $query->where('name', 'Sales Rep');
            }
        ])->get();
        return view('tenant.customer.addEdit', compact('leadSources', 'jobTypes', 'users','customer'));


    }

    /**
     * Update the specified resource in storage.
     */
    public function update(CustomerRequest $request, Customer $customer)
    {
        
        $input = $request->all();
        $input['updated_by'] = auth()->user()->id;

        $customer->update($input);

        $customerContactAlternate = $request->alternate;
        $customerContactAlternate['customer_id'] = $customer->id;
        $customerContactAlternate['type'] = 'Alternate';

        $customerContactOffice = $request->office;
        $customerContactOffice['customer_id'] = $customer->id;
        $customerContactOffice['type'] = 'Office';

        $customer->alternate()->update($customerContactAlternate);
        $customer->office()->update($customerContactOffice);

        return redirect()->back()
            ->with('success', 'Customer updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Customer $customer)
    {
        $customer->contacts()->delete();
        $customer->delete();

        return redirect()->back()
            ->with('success', 'Customer deleted successfully.');
    }
}
