<?php

namespace App\Http\Controllers\Tenant;

use App\Http\Controllers\Controller;
use App\Http\Requests\Tenant\JobType\JobTypeRequest;
use App\Models\JobType;
use Illuminate\Http\Request;
use Yajra\DataTables\DataTables;

class JobTypeController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        if ($request->ajax()) {
            $data = JobType::orderby('id', 'DESC');

            return DataTables::of($data)
                ->addIndexColumn()
                ->addColumn('action', function ($row) {
                    $action = '<span class="action-buttons">
                  
            <a  href="' . route("job-type.edit", $row) . '" class="btn btn-sm btn-info"><i class="las la-pen"></i>
            </a>

            <a href="' . route("job-type.destroy", $row) . '"
                    class="btn btn-sm btn-danger remove_us"
                    title="Delete User"
                    data-toggle="tooltip"
                    data-placement="top"
                    data-method="DELETE"
                    data-confirm-title="Please Confirm"
                    data-confirm-text="Are you sure that you want to delete this?"
                    data-confirm-delete="Yes, delete it!">
                    <i class="las la-trash"></i>
                </a>
        ';
                    return $action;
                })
                ->rawColumns(['action'])
                ->make(true);
        }
        return view('tenant.job-type.index');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('tenant.job-type.addEdit');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(JobTypeRequest $request)
    {
       
        $inputs = $request->all();
        JobType::create($inputs);

        return back()->with('success', 'Added successfully!');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $jobType = JobType::find($id);
        return view('tenant.job-type.addEdit', compact('jobType'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(JobTypeRequest $request, string $id)
    {
       
        $inputs = $request->all();
        $user = JobType::find($id);
        $user->update($inputs);
        return back()->with('success', 'Updated successfully!');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $data = JobType::find($id);
        $data->delete();
        return back()->with('success', 'Deleted successfully!');
    }
}