<?php

namespace App\Http\Controllers\Tenant;

use App\Http\Controllers\Controller;
use App\Http\Requests\Tenant\LeadSource\LeadSourceRequest;
use App\Models\LeadSource;
use Illuminate\Http\Request;
use Yajra\DataTables\DataTables;

class LeadSourceController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        if ($request->ajax()) {
            $data = LeadSource::orderby('id', 'DESC');

            return DataTables::of($data)
                ->addIndexColumn()
                ->addColumn('action', function ($row) {
                    $action = '<span class="action-buttons">
                  
            <a  href="' . route("lead-source.edit", $row) . '" class="btn btn-sm btn-info"><i class="las la-pen"></i>
            </a>

            <a href="' . route("lead-source.destroy", $row) . '"
                    class="btn btn-sm btn-danger remove_us"
                    title="Delete User"
                    data-toggle="tooltip"
                    data-placement="top"
                    data-method="DELETE"
                    data-confirm-title="Please Confirm"
                    data-confirm-text="Are you sure that you want to delete this?"
                    data-confirm-delete="Yes, delete it!">
                    <i class="las la-trash"></i>
                </a>
        ';
                    return $action;
                })
                ->rawColumns(['action'])
                ->make(true);
        }
        return view('tenant.lead-source.index');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('tenant.lead-source.addEdit');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(LeadSourceRequest $request)
    {
       
        $inputs = $request->all();
         LeadSource::create($inputs);

        return back()->with('success', 'Added successfully!');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $leadSource = LeadSource::find($id);
        return view('tenant.lead-source.addEdit', compact('leadSource'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(LeadSourceRequest $request, string $id)
    {
       
        $inputs = $request->all();
        $user = LeadSource::find($id);
        $user->update($inputs);
        return back()->with('success', 'Updated successfully!');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $user = LeadSource::find($id);
        $user->delete();
        return back()->with('success', 'Deleted successfully!');
    }
}
