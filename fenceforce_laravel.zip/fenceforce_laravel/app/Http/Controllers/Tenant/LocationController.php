<?php

namespace App\Http\Controllers\Tenant;

use App\Http\Controllers\Controller;
use App\Models\Location;
use App\Models\Measurement;
use App\Models\ProductFamily;
use App\Models\ProductHeight;
use Illuminate\Http\Request;
use Yajra\DataTables\Facades\DataTables;

class LocationController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        if ($request->ajax()) {
            $data = Location::where('customer_id', $request->customer_id)
                ->orderBy('id', 'DESC')
                ->get();

            return DataTables::of($data)
                ->addIndexColumn()
                ->addColumn('action', function ($row) {
                    $locationLength = Measurement::where('location_id', $row->id)->orderBy('id', 'DESC')->first();
                    $total_length = isset($locationLength) && !empty($locationLength) ? $locationLength->total_length : 0;
                    $action = '                                        <div class="flex gap-2">
                                    <div class="edit">
                                        <a href=' . route("location.show", $row) . ' data-modal-target="showModal" class="py-1 text-xs text-white btn bg-custom-500 border-custom-500 hover:text-white hover:bg-custom-600 hover:border-custom-600 focus:text-white focus:bg-custom-600 focus:border-custom-600 focus:ring focus:ring-custom-100 active:text-white active:bg-custom-600 active:border-custom-600 active:ring active:ring-custom-100 dark:ring-custom-400/20 edit-item-btn">View</a>
                                    </div>
                                    <div class="proposal">
                                        <button data-modal-target="addProposal" data-id=' . $row->id . ' data-length=' .$total_length . '  class="py-1 text-xs text-white btn bg-custom-500 border-custom-500 hover:text-white hover:bg-custom-600 hover:border-custom-600 focus:text-white focus:bg-custom-600 focus:border-custom-600 focus:ring focus:ring-custom-100 active:text-white active:bg-custom-600 active:border-custom-600 active:ring active:ring-custom-100 dark:ring-custom-400/20 edit-item-btn addProposal">Proposal</button>
                                    </div>
                                    <div class="remove">
                                        <a href=' . route("location.destroy", $row) . '  class="py-1 text-xs text-white bg-red-500 border-red-500 btn hover:text-white hover:bg-red-600 hover:border-red-600 focus:text-white focus:bg-red-600 focus:border-red-600 focus:ring focus:ring-red-100 active:text-white active:bg-red-600 active:border-red-600 active:ring active:ring-red-100 dark:ring-custom-400/20 remove-item-btn">Remove</a>
                                    </div>
                                </div>
                                        
        ';


                    return $action;
                })
                ->rawColumns(['action'])
                ->make(true);
        }
        return view('tenant.customer.show');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('tenant.location.addEdit');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {

        $inputs = $request->all();
        Location::create($inputs);

        return back()->with('success', 'Added successfully!');
    }

    /**
     * Display the specified resource.
     */
    public function show(Location $location)
    {
        $families = ProductFamily::all();
        $heights = ProductHeight::all();
        return view('tenant.location.show', compact('location', 'families', 'heights'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $jobType = Location::find($id);
        return view('tenant.location.addEdit', compact('jobType'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {

        $inputs = $request->all();
        $location = Location::find($id);
        $location->update($inputs);
        return back()->with('success', 'Updated successfully!');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $data = Location::find($id);
        $data->delete();
        return back()->with('success', 'Deleted successfully!');
    }
}
