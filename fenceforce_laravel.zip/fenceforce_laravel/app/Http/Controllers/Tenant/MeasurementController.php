<?php

namespace App\Http\Controllers\Tenant;

use App\Http\Controllers\Controller;
use App\Models\Location;
use App\Models\Measurement;
use Illuminate\Http\Request;

class MeasurementController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return view('tenant.measurement.index');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $location = Location::find($request->id);
        
        if (count($request->measurement['result']['segments']) > 0) {
            Measurement::where('location_id', $request->id)->delete();
            foreach ($request->measurement['result']['segments'] as $segment) {
                Measurement::updateOrCreate(
                    [
                        'location_id' => $request->id,
                        'customer_id' => $location->customer_id,
                        'user_id' => auth()->user()->id,
                        'start_location_lat' => $segment['start_location']['lat'],
                        'start_location_lng' => $segment['start_location']['lng'],
                        'end_location_lat' => $segment['end_location']['lat'],
                        'end_location_lng' => $segment['end_location']['lng'],
                    ],
                    [
                        'distance' => $segment['length']['value'],
                        'total_length' => $request->measurement['result']['length'],
                        'total_area' => $request->measurement['result']['area'],
                        'measurement_data' => json_encode($request->measurement)
                    ]
                );
            }
        }

        return response()->json(['message' => 'Measurement saved successfully']);
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        $location = Location::find($id);
        return view('tenant.measurement.index', compact('location'));
    }


    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }

    /**
     * Get all measurements for a location.
     */
    public function getMeasurements(string $id)
    {
        $measurements = Measurement::where('location_id', $id)->orderBy('created_at', 'desc')->get();
        return response()->json($measurements);
    }
}
