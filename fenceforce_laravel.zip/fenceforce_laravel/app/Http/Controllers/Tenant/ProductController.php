<?php

namespace App\Http\Controllers\Tenant;

use App\Http\Controllers\Controller;
use App\Http\Requests\Tenant\Product\ProductRequest;
use App\Models\Product;
use App\Models\ProductCategory;
use App\Models\ProductFamily;
use App\Models\ProductHeight;
use App\Models\ProductItem;
use Illuminate\Http\Request;
use Yajra\DataTables\Facades\DataTables;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        if ($request->ajax()) {
            $data = Product::with('family', 'category', 'height')->orderby('id', 'DESC');

            return DataTables::of($data)
                ->addIndexColumn()
                ->addColumn('action', function ($row) {
                    $action = '<span class="action-buttons">
                  
            <a  href="' . route("product.edit", $row) . '" class="btn btn-sm btn-info"><i class="las la-pen"></i>
            </a>

            <a href="' . route("product.destroy", $row) . '"
                    class="btn btn-sm btn-danger remove_us"
                    title="Delete User"
                    data-toggle="tooltip"
                    data-placement="top"
                    data-method="DELETE"
                    data-confirm-title="Please Confirm"
                    data-confirm-text="Are you sure that you want to delete this?"
                    data-confirm-delete="Yes, delete it!">
                    <i class="las la-trash"></i>
                </a>
        ';
                    return $action;
                })
                ->addColumn('productsItem', function ($row) {
                    $items = '';
                    foreach ($row->productItems as $item) {
                        $items .= '<div class="flex gap-2">
                        <div class="font-semibold">' . $item->name . '</div>
                        <div>' . $item->value . '</div>
                    </div>';
                    }
                    return $items;
                })
                ->rawColumns(['action','productsItem'])
                ->make(true);
        }
        return view('tenant.product.index');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $families = ProductFamily::all();
        $heights = ProductHeight::all();
        $categories = ProductCategory::all();
        return view('tenant.product.addEdit', compact('families', 'heights', 'categories'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(ProductRequest $request)
    {

        $inputs = $request->all();

        $product = Product::create($inputs);
        if (isset($inputs['productItemName'])) {
            foreach ($inputs['productItemName'] as $key => $value) {
                ProductItem::create([
                    'product_id' => $product->id,
                    'name' => $value,
                    'value' => $inputs['productItemValue'][$key]
                ]);
            }
        }


        return back()->with('success', 'Added successfully!');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Product $product)
    {
        $families = ProductFamily::all();
        $heights = ProductHeight::all();
        $categories = ProductCategory::all();


        return view('tenant.product.addEdit', compact('product', 'families', 'heights', 'categories'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(ProductRequest $request, string $id)
    {

        $inputs = $request->all();
      
        $result = Product::find($id);
        $result->update($inputs);
        if (isset($inputs['productItemName'])) {
            foreach ($inputs['productItemName'] as $key => $value) {
                ProductItem::updateOrCreate(
                    ['product_id' => $result->id, 'name' => $value],
                    [
                        'product_id' => $result->id,
                        'name' => $value,
                        'value' => $inputs['productItemValue'][$key]
                    ]
                );
            }
        }

        return back()->with('success', 'Updated successfully!');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $user = Product::find($id);
        $user->delete();
        return back()->with('success', 'Deleted successfully!');
    }
}
