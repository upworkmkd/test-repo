<?php

namespace App\Http\Controllers\Tenant;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\ProductCategory;
use App\Models\ProductItem;
use App\Models\Proposal;
use App\Models\ProposalItem;
use Illuminate\Http\Request;
use Yajra\DataTables\Facades\DataTables;

class ProposalController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        if ($request->ajax()) {
            $data = Proposal::with('location');
            if ($request->customer_id) {
                $data->where('customer_id', $request->customer_id);
            }
            if ($request->location_id) {
                $data->where('location_id', $request->location_id);
            }
            $data->orderBy('id', 'DESC')
                ->get();



            return DataTables::of($data)
                ->addIndexColumn()
                ->addColumn('action', function ($row) {
                    $action = '
                                <div class="flex gap-2">
                                    <div class="edit">
                                        <a href=' . route("proposal.show", $row) . ' data-modal-target="showModal" class="py-1 text-xs text-white btn bg-custom-500 border-custom-500 hover:text-white hover:bg-custom-600 hover:border-custom-600 focus:text-white focus:bg-custom-600 focus:border-custom-600 focus:ring focus:ring-custom-100 active:text-white active:bg-custom-600 active:border-custom-600 active:ring active:ring-custom-100 dark:ring-custom-400/20 edit-item-btn">View</a>
                                    </div>
                                    </div>
                ';
                    return $action;
                })
                ->rawColumns(['action'])
                ->make(true);
        }
        return view('tenant.proposal.show');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {

        $input = $request->all();
        $proposal = Proposal::create([
            'product_family_id' => $input['family_id'],
            'location_id' => $input['location_id'],
            'customer_id' => $input['customer_id'],
            'name' => $input['name'],
            'notes' => $input['notes'],
            'created_by' => auth()->user()->id,

        ]);

        $proposalItems = $input['product'];
        $totalPrice = 0;
        foreach ($proposalItems as $productId => $value) {

            ProposalItem::create([
                'proposal_id' => $proposal->id,
                'product_id' => $productId,
                'product_item_id' => $value["'productItem'"],
                'quantity' => $value["'quantity'"],
                'total_price' => $value["'total_price'"],
            ]);
            $totalPrice += $value["'total_price'"];
        }

        $proposal->total_materials_cost = $totalPrice;
        $proposal->save();

        return redirect()->back()
            ->with('success', 'Proposal created successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show(Proposal $proposal)
    {
        $locationArea = $proposal->location_id;
        return view('tenant.proposal.show', compact('proposal'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Proposal $proposal)
    {
       
        $inputs = $request->all();
        $proposal->update($inputs);
        return redirect()->back()
            ->with('success', 'Proposal updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }

    public function getCategory(Request $request)
    {

        $familyId = $request->family_id;

        $uniqueCategoryIds = Product::where('product_family_id', $familyId)
            ->distinct()
            ->pluck('product_category_id');
        $uniqueCategoryNames = ProductCategory::whereIn('id', $uniqueCategoryIds)->get();

        return response()->json($uniqueCategoryNames);
    }

    public function getProducts(Request $request)
    {
        $height_id = $request->input('height_id');
        $category_id = $request->input('category_id');
        $products = Product::where('product_height_id', $height_id)
            ->where('product_category_id', $category_id)
            ->get();
        return response()->json($products);
    }

    public function getProductsItem(Request $request)
    {
        $product_id = $request->input('product_id');
        $productItem = ProductItem::where('product_id', $product_id)->get();
        $product = Product::find($product_id);
        return response()->json(['productItem' => $productItem, 'product' => $product]);
    }
}
