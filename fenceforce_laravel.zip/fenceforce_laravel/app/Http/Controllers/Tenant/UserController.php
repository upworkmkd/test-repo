<?php

namespace App\Http\Controllers\Tenant;

use App\Http\Controllers\Controller;
use App\Http\Requests\Tenant\User\StoreUserRequest;
use App\Http\Requests\Tenant\User\UpdateUserRequest;
use Illuminate\Http\Request;
use DataTables;
use App\Models\User;
use Spatie\Permission\Models\Role;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        if ($request->ajax()) {
            $data = User::with('roles')->orderby('id', 'DESC');

            return DataTables::of($data)
                ->addIndexColumn()
                ->addColumn('action', function ($row) {
                    $action = '<span class="action-buttons">
                  
            <a  href="' . route("users.edit", $row) . '" class="btn btn-sm btn-info"><i class="las la-pen"></i>
            </a>

            <a href="' . route("users.destroy", $row) . '"
                    class="btn btn-sm btn-danger remove_us"
                    title="Delete User"
                    data-toggle="tooltip"
                    data-placement="top"
                    data-method="DELETE"
                    data-confirm-title="Please Confirm"
                    data-confirm-text="Are you sure that you want to delete this User?"
                    data-confirm-delete="Yes, delete it!">
                    <i class="las la-trash"></i>
                </a>
        ';
                    return $action;
                })
                ->rawColumns(['action'])
                ->make(true);
        }
        return view('tenant.users.index');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('tenant.users.addEdit');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreUserRequest $request)
    {
        app()[\Spatie\Permission\PermissionRegistrar::class]->forgetCachedPermissions();
        $role = Role::updateOrCreate(['name' => $request->role, 'guard_name' => 'web']);
        $inputs = $request->all();
        $inputs['password'] = bcrypt($request->password);
        $user = User::create($inputs);

        $user->assignRole($role);
        return back()->with('success', 'User added successfully!');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $user = User::find($id);
        return view('tenant.users.addEdit', compact('user'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateUserRequest $request, string $id)
    {
        app()[\Spatie\Permission\PermissionRegistrar::class]->forgetCachedPermissions();
        $role = Role::updateOrCreate(['name' => $request->role, 'guard_name' => 'web']);
        $inputs = $request->all();
        $inputs['password'] = bcrypt($request->password);
        $user = User::find($id);
        $user->update($inputs);
        $user->syncRoles($role);
        return back()->with('success', 'User updated successfully!');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $user = User::find($id);
        $user->delete();
        return back()->with('success', 'User deleted successfully!');
    }
}
