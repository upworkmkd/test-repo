<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'user_id',
        'address',
        'city',
        'state',
        'zip',
        'country',
        'company',
        'notes',
        'schedule_status',
        'updated_by',
        'log_date',
        'lead_source_id',
        'job_type_id',
        'sale_req_id',

    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function leadSource()
    {
        return $this->belongsTo(LeadSource::class);
    }

    public function jobType()
    {
        return $this->belongsTo(JobType::class);
    }

    public function saleReq()
    {
        return $this->belongsTo(User::class, 'sale_req_id');
    }

    public function updatedBy()
    {
        return $this->belongsTo(User::class, 'updated_by');
    }

    public function contacts()
    {
        return $this->hasMany(CustomerContact::class);
    }

    public function office()
    {
        return $this->contacts()->where('type', 'Office')->first();
    }

    public function alternate()
    {
        return $this->contacts()->where('type', 'Alternate')->first();
    }

}
