<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Location extends Model
{
    use HasFactory;

    protected $fillable = [
        'customer_id',
        'name',
        'address',
        'city',
        'state',
        'zip',
        'country',
        'contact_name',
        'phone',
        'email',
        'cell',
        'log',
        'lat',
    ];


    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }

    public function measurements()
    {
        return $this->hasMany(Measurement::class, 'location_id');
    }
    

    
}
