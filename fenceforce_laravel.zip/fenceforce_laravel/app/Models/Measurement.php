<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Measurement extends Model
{
    use HasFactory;

    protected $fillable = [
        'location_id',
        'customer_id',
        'user_id',
        'start_location_lat',
        'start_location_lng',
        'end_location_lat',
        'end_location_lng',
        'distance',
        'total_length',
        'total_area',
        'measurement_data'
    ];

    public function location()
    {
        return $this->belongsTo(Location::class);
    }

    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
