<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;

    protected $fillable = [
        'name','product_family_id','product_category_id','product_height_id','length_on_ground','cost','price','part_number'
    ];

    public function family()
    {
        return $this->belongsTo(ProductFamily::class, 'product_family_id');
    }

    public function category()
    {
        return $this->belongsTo(ProductCategory::class, 'product_category_id');
    }


    public function height()
    {
        return $this->belongsTo(ProductHeight::class, 'product_height_id');
    }

    public function productItems()
    {
        return $this->hasMany(ProductItem::class);
    }
    
    
}
