<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Proposal extends Model
{
    use HasFactory;

    protected $fillable = [
        'location_id',
        'product_family_id',
        'name',
        'notes',
        'map_image',
        'form_workup',
        'misc',
        'subtotal',
        'waste_rate',
        'waste_price',
        'total_materials_cost',
        'labor_rate',
        'labor_cost',
        'installation',
        'clearing',
        'mileage',
        'other',
        'total_labour_cost',
        'overhead_rate',
        'profit_calc_rate',
        'bond_rate',
        'direct_cost',
        'overhead',
        'total_cost',
        'profit',
        'selling_price',
        'bond_price',
        'total_bid',
        'status',
        'type',
        'mail_sent',
        'created_by',
        'customer_id'
    ];

    public function location()
    {
        return $this->belongsTo(Location::class);
    }

    public function productFamily()
    {
        return $this->belongsTo(ProductFamily::class);
    }

    public function proposalItems()
    {
        return $this->hasMany(ProposalItem::class);
    }

    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }

    public function createdBy()
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function getTotalProposalItemCost()
    {
        return $this->proposalItems->sum('total_price');
    }

    protected $casts = [
        'created_at' => 'datetime:M d, Y h:i:s',
        'updated_at' => 'datetime:M d, Y h:i:s',
    ];
}
