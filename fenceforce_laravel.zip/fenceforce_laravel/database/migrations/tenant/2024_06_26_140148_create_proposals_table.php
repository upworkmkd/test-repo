<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('proposals', function (Blueprint $table) {
            $table->id();
            $table->foreignId('location_id')->constrained()->onDelete('cascade');
            $table->foreignId('product_family_id')->constrained()->onDelete('cascade');
            $table->foreignId('customer_id')->constrained()->onDelete('cascade');
            $table->string('name');
            $table->longText('notes')->nullable();
            $table->string('map_image')->nullable();
            $table->decimal('form_workup', 11, 2)->nullable();
            $table->decimal('misc', 11, 2)->nullable();
            $table->decimal('subtotal', 11, 2)->nullable();    
            $table->decimal('waste_rate', 11, 2)->nullable();
            $table->decimal('waste_price', 11, 2)->nullable();
            $table->decimal('total_materials_cost', 11, 2)->nullable();
            $table->decimal('labor_rate', 11, 2)->nullable();
            $table->decimal('labor_cost', 11, 2)->nullable();
            $table->decimal('installation', 11, 2)->nullable();
            $table->decimal('clearing', 11, 2)->nullable();
            $table->decimal('mileage', 11, 2)->nullable();
            $table->decimal('other', 11, 2)->nullable();
            $table->decimal('total_labour_cost', 11, 2)->nullable();
            $table->decimal('overhead_rate', 11, 2)->nullable();
            $table->decimal('profit_calc_rate', 11, 2)->nullable();
            $table->decimal('bond_rate', 11, 2)->nullable();
            $table->decimal('direct_cost', 11, 2)->nullable();
            $table->decimal('overhead', 11, 2)->nullable();
            $table->decimal('total_cost', 11, 2)->nullable();
            $table->decimal('profit', 11, 2)->nullable();
            $table->decimal('selling_price', 11, 2)->nullable();
            $table->decimal('bond_price', 11, 2)->nullable();
            $table->decimal('total_bid', 11, 2)->nullable();
            $table->enum('status', ['Active', 'Accepted', 'Declined', 'Closed'])->default('Active');
            $table->enum('type', ['Bid', 'Proposal'])->default('Proposal');
            $table->tinyInteger('mail_sent')->default(0)->comment('0 = not sent, 1 = sent');
            $table->integer('created_by');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('proposals');
    }
};
