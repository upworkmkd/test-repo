<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('measurements', function (Blueprint $table) {
            $table->id();
            $table->foreignId('location_id')->constrained();
            $table->foreignId('customer_id')->constrained();
            $table->foreignId('user_id')->constrained();
            $table->string('start_location_lat')->nullable();
            $table->string('start_location_lng')->nullable();
            $table->string('end_location_lat')->nullable();
            $table->string('end_location_lng')->nullable();
            $table->string('distance')->nullable();
            $table->string('total_length')->nullable();
            $table->string('total_area')->nullable();
            $table->longText('measurement_data')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('measurements');
    }
};
