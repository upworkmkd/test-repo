
    
    
    // Add proposal
    $(function() {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $(document).on("change", "#family_id", function() {
            var family_id = $(this).val();
            $.ajax({
                url: "{{ route('proposal.getCategory') }}",
                type: "POST",
                data: {
                    family_id: family_id
                },
                success: function(data) {
                    if (data.length > 0) {
                        var html = '';
                        data.forEach(element => {
                            html += `<div class="mb-3 category-box" data-category-id="${element.id}">
                                        <h6 class="text-15 grow">${element.name}</h6>
                                        <hr />

                                        <label for="documentsType" class="inline-block mb-2 text-base font-medium">Select height</label>
                                        <select name="product_height_id"  class="form-select height-select"  data-category-id="${element.id}" required>
                                            <option value="">Select Height</option>
                                            @foreach($heights as $height)
                                            <option value="{{ $height->id }}">{{ $height->height }}</option>
                                            @endforeach
                                        </select>
                                            <div class="products-box">
                                            </div>
                                            <div class="products-item-box">
                                            </div>


                                    </div>`;
                        });

                        $('.category-box').html(html);
                    }
                },
                error: function(data) {
                    console.log(data);
                }
            });
        });

        // Height change
        $(document).on("change", ".height-select", function() {
            var height_id = $(this).val();
            var category_id = $(this).data('category-id');
            var $productsBox = $(this).closest('.category-box').find('.products-box');

            $.ajax({
                url: "{{ route('proposal.getProducts') }}", // Adjust the route as necessary
                type: "POST",
                data: {
                    height_id: height_id,
                    category_id: category_id
                },
                success: function(products) {
                    if (products.length > 0) {
                        var productHtml = '<label for="documentsType" class="inline-block mb-2 text-base font-medium">Select Products</label>';
                        products.forEach(product => {
                            productHtml += `
                        <div class="form-check">
                            <input class="form-check-input select-product" type="checkbox" value="${product.id}" id="product_${product.id}" name="productId[]" >
                            <label class="form-check-label" for="product_${product.id}">
                                ${product.name}
                            </label>
                              <div class="product-item-container" data-product-id="${product.id}">
                            </div>
                        </div>`;
                        });

                        $productsBox.html(productHtml);
                    } else {
                        $('.products-item-box').html('');
                        $productsBox.html('<p>No products available for this height.</p>');
                    }
                },
                error: function(data) {
                    console.log(data);
                }
            });
        });

        // Product item change
        $(document).on("change", ".select-product", function() {
            var product_id = $(this).val();
            var $productItemContainer = $(this).closest('.form-check').find('.product-item-container');

            if ($(this).is(':checked')) {
                $.ajax({
                    url: "{{ route('proposal.getProductsItem') }}",
                    type: "POST",
                    data: {
                        product_id: product_id,
                    },
                    success: function(data) {
                        console.log(data);
                        if (data.productItem) {
                            var productItemHtml = `<div class="product-item" data-product-id="${product_id}"><label for="documentsType" class="inline-block mb-2 text-base font-medium">Select Product Item</label>`;
                            productItemHtml += `<select name="product[${product_id}]['productItem']" class="form-select" required> `;
                            productItemHtml += '<option value="">Select Product Item</option>';
                            data.productItem.forEach(productItem => {
                                productItemHtml += `<option value="${productItem.id}">(${productItem.name}): ${productItem.value}</option>`;
                            });
                            productItemHtml += '</select>';
                            productItemHtml += `
                        <div class="mb-4">
                            <label for="" class="inline-block mb-2 text-base font-medium">Enter a quantity:
                            </label>
                            <input type="text" name="product[${product_id}]['quantity']" class="form-input quantity-change" placeholder="Enter...">
                        </div>
                        <div class="mb-4">
                            <label  class="inline-block mb-2 text-base font-medium">Product Price is: $
                            </label>
                            <input type="text" readonly class="form-input price" value="${data.product.price}" >
                        </div>
                          <div class="mb-4">
                            <label  class="inline-block mb-2 text-base font-medium">Total Price: $
                            </label>
                            <input type="text" name="product[${product_id}]['total_price']" class="form-input total-price" placeholder="Enter...">
                        </div>
                           <div class="mb-4">
                            <label  class="inline-block mb-2 text-base font-medium">Part Number
                            </label>
                            <input type="text" readonly class="form-input" value="${data.product.part_number}" >
                        </div>
                           <div class="mb-4">
                            <label  class="inline-block mb-2 text-base font-medium">Image Upload
                            </label>
                            <input type="file" name="product[${product_id}]['image']" class="form-input" >
                        </div>
                        </div>
                        `;

                            $productItemContainer.html(productItemHtml);


                        }
                    },
                    error: function(data) {
                        console.log(data);
                    }

                });
            } else {
                $productItemContainer.html('');

            }
        });

        // Quantity change
        $(document).on("change", ".quantity-change", function() {
            var quantity = $(this).val();
            var $productsBox = $(this).closest('.category-box').find('.total-price');
            var price = $(this).closest('.category-box').find('.price').val();
            var total_price = quantity * price;
            $productsBox.val(total_price);
        });

        
    });